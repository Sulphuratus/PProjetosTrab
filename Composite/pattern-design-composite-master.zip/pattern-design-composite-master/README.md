# pattern-design-composite

## Link Youtube:
### https://youtu.be/cE9ZBNAbSAg

## UML
![CompositeUML](https://user-images.githubusercontent.com/61429797/89475448-7cdd5880-d75e-11ea-89f9-33cc6f0ea1d1.png)

